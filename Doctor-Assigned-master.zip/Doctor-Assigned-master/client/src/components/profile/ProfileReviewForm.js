import React, {useState} from 'react';
import PropTypes from 'prop-types';
import {connect} from 'react-redux';
import {addReview} from '../../actions/profile';

const ProfileReviewForm = () => {
    return (
        <div>
            
        </div>
    )
}

export default ProfileReviewForm
